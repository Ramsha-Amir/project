package com.example.ibra.oxp.utils;

public class Config {
    public static String BASE_URL = "http://192.168.10.35:8000/";
       // public static String BASE_URL = "http://192.168.1.168:8000/";
    //public static String BASE_URL = "http://10.0.2.2:8000/";
    public static String OXP_URL = BASE_URL+"oxp/";
    public static String IMAGE_URL = OXP_URL+"images/";
}
